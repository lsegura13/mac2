//
//  DogsTableViewController.h
//  TableViewDefaultExample
//
//  Created by Estudiantes on 29/10/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DogsTableViewController : UITableViewController

@end
