//
//  CustomTableViewCell.m
//  CustomTableViewExample
//
//  Created by Estudiantes on 5/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "CustomTableViewCell.h"
#import "Dog.h"
@interface CustomTableViewCell()
@property (strong, nonatomic) IBOutlet UILabel *left;
@property (strong, nonatomic) IBOutlet UILabel *right;

@end

@implementation CustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setupCellWithDog:(Dog*)dog{
    self.left.text = dog.name;
    self.right.text = dog.color;
}

@end
