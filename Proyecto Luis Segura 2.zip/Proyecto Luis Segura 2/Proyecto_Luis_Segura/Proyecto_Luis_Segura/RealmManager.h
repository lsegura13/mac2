//
//  RealmManager.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/9/16.
//  Copyright © 2016 user122705. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <Realm/Realm.h>

@interface RealmManager : NSObject
+(RLMResults*)getAllCategories;
+(RLMArray*)getRoutinesWithCategoryName:(NSString*)categoryName;
+(void)createRoutinesWithCategoryName:(NSString*)categoryName routineTitle:(NSString*)routineTitle routineDescription:(NSString*)routineDescription;
@end
