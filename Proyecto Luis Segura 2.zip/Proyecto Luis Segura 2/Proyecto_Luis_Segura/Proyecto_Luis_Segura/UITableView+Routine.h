//
//  UITableView+Routine.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/1/16.
//  Copyright © 2016 user122705. All rights reserved.
//



#import <UIKit/UIKit.h>

@interface UITableView (RegisterCustomCell)
-(void)registerCellWithIdentifier:(NSString*)identifier;
@end
