//
//  main.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/22/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
