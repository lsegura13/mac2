//
//  Category.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/24/16.
//  Copyright © 2016 user122705. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <Realm/Realm.h>
#import "Routine.h"

@interface Category : RLMObject
@property RLMArray<Routine *><Routine> *routine;
@property NSString *categoryTitle;
@property NSString *imageName;
@end
RLM_ARRAY_TYPE(Category)
