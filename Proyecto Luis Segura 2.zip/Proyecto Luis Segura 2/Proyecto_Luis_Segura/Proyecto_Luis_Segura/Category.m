//
//  Category.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/24/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "Category.h"
@implementation Category
@end
