//
//  AddRoutineTableViewController.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/1/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "AddRoutineTableViewController.h"
#import "Routine.h"
#import "RealmManager.h"


@interface AddRoutineTableViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField1;

@property (weak, nonatomic) IBOutlet UITextView *textField2;

//@property (weak, nonatomic) IBOutlet MKMapView *map;

@end

@implementation AddRoutineTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self addSaveUIBarButtonItem];
}

-(void)addSaveUIBarButtonItem{
    UIBarButtonItem *saveBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveNews)];
    self.navigationItem.rightBarButtonItem = saveBarButtonItem;
}

-(void)saveNews{
    [RealmManager createRoutinesWithCategoryName:self.categoryName routineTitle:self.textField1.text routineDescription:self.textField2.text];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
}

#pragma mark - Table view data source

@end



