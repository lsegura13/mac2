//
//  Routine.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/30/16.
//  Copyright © 2016 user122705. All rights reserved.
//


#import <Foundation/Foundation.h>
#import <Realm/Realm.h>
@class Category;

@interface Routine : RLMObject
@property NSString *routineTitle;
@property NSString *routineDescription;
@property NSDate *routineDate;
@property Category *category;
@end
RLM_ARRAY_TYPE(Routine) // define RLMArray<News>
