//
//  RoutineTableViewCell.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/28/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "RoutineTableViewCell.h"
#import "Routine.h"

@interface RoutineTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *descriptionlabel;
@property (weak, nonatomic) IBOutlet UILabel *datelabel;


@end

@implementation RoutineTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)configureCellWithNews:(Routine*)newsObject{
    self.descriptionlabel.text = newsObject.routineDescription;
    self.datelabel.text = [self getDateInStringFormatWithDate:newsObject.routineDate];
}


-(NSString*)getDateInStringFormatWithDate:(NSDate*)date{
    NSString *localizedDateTime = [NSDateFormatter localizedStringFromDate:date dateStyle:NSDateFormatterMediumStyle timeStyle:NSDateFormatterMediumStyle];
    return localizedDateTime;
}
@end
