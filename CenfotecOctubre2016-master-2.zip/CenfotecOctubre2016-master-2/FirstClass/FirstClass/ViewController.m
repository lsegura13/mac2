//
//  ViewController.m
//  FirstClass
//
//  Created by Cesar Brenes on 10/22/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import "ViewController.h"
#import "SaludoViewController.h"


@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *NameText;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSLog(@"ALGO");
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)gotonextstring:(id)sender {
    NSLog(@"PRESIONO EL BOTON");
    SaludoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SaludoViewController"];
    nextViewController.personName = self.NameText.text;
    [self.navigationController pushViewController:nextViewController animated:YES];
}


@end
