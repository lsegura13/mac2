//
//  TableViewController.m
//  Homework_2
//
//  Created by user122705 on 11/8/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "TableViewController.h"
#define ALGORITMO @"algoritmo"
#define RESULTADO @"resultado"

@interface TableViewController ()
@property(nonatomic,strong) NSArray *multiplicacionArray;
@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self createDictionary];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)createDictionary{
    
    NSDictionary *firstDictionary = @{ALGORITMO:@"7X1=",RESULTADO:@"7"};
    NSDictionary *secondDictionary = @{ALGORITMO:@"7X2=",RESULTADO:@"14"};
    NSDictionary *thirdDictionary = @{ALGORITMO:@"7X3=",RESULTADO:@"21"};
    NSDictionary *fourthDictionary = @{ALGORITMO:@"7X4=",RESULTADO:@"28"};
    NSDictionary *fifthDictionary = @{ALGORITMO:@"7X5=",RESULTADO:@"35"};
    NSDictionary *sixthDictionary = @{ALGORITMO:@"7X6=",RESULTADO:@"42"};
    NSDictionary *seventhDictionary = @{ALGORITMO:@"7X7=",RESULTADO:@"49"};
    NSDictionary *eigthDictionary = @{ALGORITMO:@"7X8=",RESULTADO:@"56"};
    NSDictionary *ninethDictionary = @{ALGORITMO:@"7X9=",RESULTADO:@"63"};
    NSDictionary *tenthDictionary = @{ALGORITMO:@"7X10=",RESULTADO:@"70"};
    NSDictionary *eleventhDictionary = @{ALGORITMO:@"7X11=",RESULTADO:@"77"};
    NSDictionary *twelfthDictionary = @{ALGORITMO:@"7X12=",RESULTADO:@"84"};
    NSDictionary *thirteenDictionary = @{ALGORITMO:@"7X13=",RESULTADO:@"91"};
    NSDictionary *fourteenthDictionary = @{ALGORITMO:@"7X14=",RESULTADO:@"98"};
    NSDictionary *fifteenDictionary = @{ALGORITMO:@"7X15=",RESULTADO:@"105"};
self.multiplicacionArray = [[NSArray alloc] initWithObjects:firstDictionary,secondDictionary,thirdDictionary,fourthDictionary,fifthDictionary,sixthDictionary,seventhDictionary,eigthDictionary,ninethDictionary,tenthDictionary,eleventhDictionary,twelfthDictionary,thirteenDictionary,fourteenthDictionary,fifteenDictionary, nil];
}

#pragma mark - Table view data source
/*- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 0;
}
 */
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.multiplicacionArray.count;

}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
 UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
 
 NSDictionary *currentAlg = self.multiplicacionArray[indexPath.row];
 cell.textLabel.text = [currentAlg valueForKey:ALGORITMO];
 if(indexPath.row % 2 == 0) {
 cell.detailTextLabel.text = [currentAlg valueForKey:RESULTADO];
 }
 else{
 //cell.detailTextLabel.text = @"";
      cell.detailTextLabel.text = [currentAlg valueForKey:RESULTADO]; }
 return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
