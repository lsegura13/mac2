//
//  Numero.h
//  Homework_3.1
//
//  Created by user122705 on 11/18/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Numero : NSObject
@property(readonly) NSString *numero;
-(id)initWithNumero:(NSString*)numero;

@end
