//
//  FibonacciiViewController.m
//  Homework_3.1
//
//  Created by user122705 on 11/18/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "FibonacciiViewController.h"
#import "FibonacciiTableViewCell.h"
#import "Numero.h"
#define CUSTOM_CELL_IDENTIFIER @"FibonacciiTableViewCell"


@interface FibonacciiViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *TableView;
@property (nonatomic, strong) NSArray *numerosArray;
@end

@implementation FibonacciiViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //[self fibonaccii];
     [self registerCustomCell];
      [self initializeNumerosArray];
    
    
    NSLog(@"SERIE");
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)registerCustomCell{
    UINib *nib = [UINib nibWithNibName:CUSTOM_CELL_IDENTIFIER bundle:nil];
    [self.TableView registerNib:nib forCellReuseIdentifier:CUSTOM_CELL_IDENTIFIER];
}


/*-(void)initializeNumerosArray{
    
    NSMutableArray *numArray = [NSMutableArray new];
    for(int index=0; index <17; index++){
        if(index<2)
        {

            Numero *newNumero =[[Numero alloc] initWithNumero:[NSString stringWithFormat:@"%d",index]];
            [numArray addObject:newNumero];
            
  }
        else
        {
            
            Numero *newNumero =[[Numero alloc] initWithNumero:[NSString stringWithFormat:@"%d",((index - 2) + (index - 1))]];
           [numArray addObject:newNumero];
            
 
        }

    }

    self.numerosArray = [[NSArray alloc] initWithArray:numArray];
    

}*/

-(void)initializeNumerosArray
{
NSMutableArray *numArray = [NSMutableArray new];
    int a = 0;
    int b = 1;
    int i;
    int result = a + b;
    Numero *newNumero =[[Numero alloc] initWithNumero:[NSString stringWithFormat:@"%d",a]];
    [numArray addObject:newNumero];
    Numero *newNumero2 =[[Numero alloc] initWithNumero:[NSString stringWithFormat:@"%d",b]];
    [numArray addObject:newNumero2];
    Numero *newNumero3 =[[Numero alloc] initWithNumero:[NSString stringWithFormat:@"%d",result]];
    [numArray addObject:newNumero3];
    for (i = 0; i<=13; i++) {
        a = b;
        b = result;
        result = a + b;
        Numero *newNumero =[[Numero alloc] initWithNumero:[NSString stringWithFormat:@"%d",result]];
        [numArray addObject:newNumero];
    }
    self.numerosArray = [[NSArray alloc] initWithArray:numArray];
}

#pragma -mark TABLE VIEW METHODS

-(NSInteger)tableView:(UITableView *)TableView numberOfRowsInSection:(NSInteger)section{
    return  self.numerosArray.count;
}

-(CGFloat)tableView:(UITableView *)TableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 160;
    
}

-(UITableViewCell *)tableView:(UITableView *)TableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    FibonacciiTableViewCell *cell = [TableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_IDENTIFIER];
    Numero *numeroToShow = self.numerosArray[indexPath.row];
    [cell setupCellWithNumero:numeroToShow];
    return cell;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
