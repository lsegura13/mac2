//
//  Numero.m
//  Homework_3.1
//
//  Created by user122705 on 11/18/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "Numero.h"
@interface Numero()
@property(nonatomic,strong) NSString *numero;
@end

@implementation Numero
-(id)initWithNumero:(NSString*)numero{
    if (self = [super init]) {
        _numero = numero;
    }
    return self;
}@end
