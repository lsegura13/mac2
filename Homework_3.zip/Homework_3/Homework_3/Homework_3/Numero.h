//
//  Numero.h
//  Homework_3
//
//  Created by user122705 on 11/17/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Numero : NSObject
@property(readonly) NSString *num;
-(id)initWithName:(NSString*)num;
@end
