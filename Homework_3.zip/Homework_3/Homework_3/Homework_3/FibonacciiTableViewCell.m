//
//  FibonacciiTableViewCell.m
//  Homework_3
//
//  Created by user122705 on 11/17/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "FibonacciiTableViewCell.h"
#import "Numero.h"
@interface FibonacciiTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *Label;

@end

@implementation FibonacciiTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setupCellWithNumero:(Numero*)numero{
    self.Label.text = numero.num;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
