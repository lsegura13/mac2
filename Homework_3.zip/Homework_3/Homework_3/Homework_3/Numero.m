//
//  Numero.m
//  Homework_3
//
//  Created by user122705 on 11/17/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "Numero.h"
@interface Numero()
@property(nonatomic,strong) NSString *num;
@end

@implementation Numero
-(id)initWithName:(NSString*)num{
    if (self = [super init]) {
        _num = num;
    }
    return self;
}@end
