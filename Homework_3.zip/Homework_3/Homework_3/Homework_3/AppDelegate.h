//
//  AppDelegate.h
//  Homework_3
//
//  Created by user122705 on 11/17/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

