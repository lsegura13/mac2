//
//  ViewController.m
//  Quiz 2 Luis Segura
//
//  Created by Estudiantes on 5/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *NameText;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)next:(id)sender {
    NSLog(@"PRESIONO EL BOTON");
    ViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CounterViewController"];    [self.navigationController pushViewController:nextViewController animated:YES];
}

@end
