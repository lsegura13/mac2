//
//  ResultadoViewController.m
//  Homework_1
//
//  Created by user122705 on 11/5/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "ResultadoViewController.h"
#import "ViewController.h"
@interface ResultadoViewController ()
@property (strong, nonatomic) IBOutlet UILabel *textresult;

@end

@implementation ResultadoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *inputstring = self.firstdigit;
    int number = [inputstring intValue];
    NSString *inputstring2 = self.seconddigit;
    int number2 = [inputstring2 intValue];
    NSString *inputstring3 = self.identificador;
    if  ([inputstring3  isEqual: @"A"]) {
        int number3 = number + number2;
        NSString* resultadofinal = [NSString stringWithFormat:@"%d", number3];
        self.textresult.text = [NSString stringWithFormat:@"El resultado de la suma es %@",resultadofinal];
        }
    else if([inputstring3  isEqual: @"B"]) {
        int number3 = number * number2;
        NSString* resultadofinal = [NSString stringWithFormat:@"%d", number3];
        self.textresult.text = [NSString stringWithFormat:@"El resultado de la multiplicacion es %@",resultadofinal];    }
    else if([inputstring3  isEqual: @"C"]) {
        int number3 = number / number2;
        NSString* resultadofinal = [NSString stringWithFormat:@"%d", number3];
        self.textresult.text = [NSString stringWithFormat:@"El resultado de la division es %@",resultadofinal];    }
    else if([inputstring3  isEqual: @"D"]) {
        int number3 = number - number2;
        NSString* resultadofinal = [NSString stringWithFormat:@"%d", number3];
        self.textresult.text = [NSString stringWithFormat:@"El resultado de la resta es %@",resultadofinal];

    }
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
