//
//  UIController.m
//  Homework_1
//
//  Created by user122705 on 11/6/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "UIController.h"

@implementation UIController

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
