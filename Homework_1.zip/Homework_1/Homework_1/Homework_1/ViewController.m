//
//  ViewController.m
//  Homework_1
//
//  Created by user122705 on 11/5/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "ViewController.h"
#import "ResultadoViewController.h"
@interface ViewController ()
@property (strong, nonatomic) IBOutlet UITextField *textlbl;
@property (strong, nonatomic) IBOutlet UITextField *textlbl2;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        NSLog(@"ALGO");    // Do any additional setup after loading the view, typically from a nib.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)press:(id)sender {
    NSLog(@"PRESIONO EL BOTON");
    ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
    nextViewController.firstdigit = self.textlbl.text;
    nextViewController.seconddigit = self.textlbl2.text;
    nextViewController.identificador = @"A";
    [self.navigationController pushViewController:nextViewController animated:YES];
}
- (IBAction)press2:(id)sender {
    NSLog(@"PRESIONO EL BOTON");
    ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
    nextViewController.firstdigit = self.textlbl.text;
    nextViewController.seconddigit = self.textlbl2.text;
    nextViewController.identificador = @"B";
    [self.navigationController pushViewController:nextViewController animated:YES];
    }
- (IBAction)press3:(id)sender {
    NSLog(@"PRESIONO EL BOTON");
    ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
    nextViewController.firstdigit = self.textlbl.text;
    nextViewController.seconddigit = self.textlbl2.text;
    nextViewController.identificador = @"C";
    NSString *valor = self.textlbl2.text;
    if ([valor isEqual: @"0"]){
        NSLog(@"NO SE PUEDE DIVIDIR ENTRE CERO");
    }
    else{
        [self.navigationController pushViewController:nextViewController animated:YES];
    }
}
- (IBAction)press4:(id)sender {
    NSLog(@"PRESIONO EL BOTON");
    ResultadoViewController *nextViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ResultadoViewController"];
    nextViewController.firstdigit = self.textlbl.text;
    nextViewController.seconddigit = self.textlbl2.text;
    nextViewController.identificador = @"D";
    [self.navigationController pushViewController:nextViewController animated:YES];
}

@end
