//
//  ViewController.h
//  Homework_1
//
//  Created by user122705 on 11/5/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

