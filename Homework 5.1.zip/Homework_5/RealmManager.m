//
//  RealmManager.m
//  Homework_5
//
//  Created by user122705 on 12/8/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "RealmManager.h"
#import "Category.h"
#import "Dogs.h"

#define CATEGORY_NAME_KEY @"CATEGORY_NAME_KEY"
#define CATEGORY_IMAGE_NAME_KEY @"CATEGORY_IMAGE_NAME_KEY"
#define CATEGORY_NAME_KEY2 @"CATEGORY_NAME_KEY2"

@implementation RealmManager


+(RLMResults*)getAllCategories{
    if ([self needsToInsertCategories]) {
        [self createDefaultCategories];
    }
    return [Category allObjects];
}

+(BOOL)needsToInsertCategories{
    RLMResults<Category *> *categories = [Category allObjects]; // retrieves all Categories from the default Realm
    if (categories.count==0) {
        return true;
    }
    return false;
}


+(NSArray*)createCategoriesDictionary{
    return [[NSArray alloc] initWithObjects:
            @{CATEGORY_NAME_KEY:@"Dog1", CATEGORY_IMAGE_NAME_KEY:@"dog1", CATEGORY_NAME_KEY2:@"Cafe"},
            @{CATEGORY_NAME_KEY:@"Dog2", CATEGORY_IMAGE_NAME_KEY:@"dog2", CATEGORY_NAME_KEY2:@"Blanco"},
            @{CATEGORY_NAME_KEY:@"Dog3", CATEGORY_IMAGE_NAME_KEY:@"dog3", CATEGORY_NAME_KEY2:@"Cafe"},
            @{CATEGORY_NAME_KEY:@"Dog4", CATEGORY_IMAGE_NAME_KEY:@"dog4", CATEGORY_NAME_KEY2:@"Blanco"},
            @{CATEGORY_NAME_KEY:@"Dog5", CATEGORY_IMAGE_NAME_KEY:@"dog5", CATEGORY_NAME_KEY2:@"Blanco"},
            @{CATEGORY_NAME_KEY:@"Dog6", CATEGORY_IMAGE_NAME_KEY:@"dog6", CATEGORY_NAME_KEY2:@"Negro"},
            @{CATEGORY_NAME_KEY:@"Dog7", CATEGORY_IMAGE_NAME_KEY:@"dog7", CATEGORY_NAME_KEY2:@"Blanco"},
            @{CATEGORY_NAME_KEY:@"Dog8", CATEGORY_IMAGE_NAME_KEY:@"dog8", CATEGORY_NAME_KEY2:@"Cafe"},
            @{CATEGORY_NAME_KEY:@"Dog9", CATEGORY_IMAGE_NAME_KEY:@"dog9", CATEGORY_NAME_KEY2:@"Negro"},
            @{CATEGORY_NAME_KEY:@"Dog10", CATEGORY_IMAGE_NAME_KEY:@"dog10", CATEGORY_NAME_KEY2:@"Cafe"},
            nil];
}

+(void)createDefaultCategories{
    NSArray *categoryArray = [self createCategoriesDictionary];
    for (NSDictionary *categoryDictionary in categoryArray) {
        Category *category = [Category new];
        category.imageName = [categoryDictionary valueForKey:CATEGORY_IMAGE_NAME_KEY];
        category.name = [categoryDictionary valueForKey:CATEGORY_NAME_KEY];
        category.color = [categoryDictionary valueForKey:CATEGORY_NAME_KEY2];
        [self insertObjectInDB:category];
    }
}



+(void)insertObjectInDB:(RLMObject*)realmObject{
    RLMRealm *realm = [RLMRealm defaultRealm];
    // Add to Realm with transaction
    [realm beginWriteTransaction];
    [realm addObject:realmObject];
    [realm commitWriteTransaction];
}


+(Category*)getCategoryWithName:(NSString*)categoryName{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.categoryTitle = %@",categoryName];
    RLMResults<Category *> *categories = [Category objectsWithPredicate:predicate];
    if (categories.count>0) {
        return categories.firstObject;
    }
    return nil;
}

+(RLMArray*)getDogsWithCategoryName:(NSString*)categoryName{
    Category *category = [self getCategoryWithName:categoryName];
    return category.dogs;
}

+(void)createDogsWithCategoryName:(NSString*)categoryName dogsTitle:(NSString*)dogsTitle dogsName:(NSString*)dogsName dogsColor:(NSString*)dogsColor{
    Category *categorySelected = [self getCategoryWithName:categoryName];
    Dogs *dogs = [Dogs new];
    dogs.dogsName = dogsTitle;
    dogs.dogsColor = dogsColor;
    
    RLMRealm *realm = [RLMRealm defaultRealm];
    [realm beginWriteTransaction];
    [realm addObject:dogs];
    [categorySelected.dogs addObject:dogs];
    [realm commitWriteTransaction];
}


@end
