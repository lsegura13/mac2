//
//  DogsViewController.m
//  Homework_5
//
//  Created by user122705 on 12/8/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "DogsViewController.h"
#import "Dogs.h"
#import "DogsTableViewCell.h"
#import "Category.h"

#import "RealmManager.h"


#define CUSTOM_CELL_ID @"DogsTableViewCell"


@interface DogsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property RLMResults *categoryArray;
@end

@implementation DogsViewController

- (void)viewDidLoad{
    [super viewDidLoad];
    self.title = @"Categorías";
    [self registerCell];
    [self initializeCategoryArray];
}

-(void)registerCell{
    UINib *nib = [UINib nibWithNibName:CUSTOM_CELL_ID bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:CUSTOM_CELL_ID];
}

-(void)initializeCategoryArray{
    self.categoryArray = [RealmManager getAllCategories];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.categoryArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DogsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_ID];
    Category *categoryToShow = self.categoryArray[indexPath.row];
    [cell setupCellWithCategoryObject:categoryToShow];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DogsViewController * dogsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DogsViewController"];
    [self.navigationController pushViewController:dogsViewController animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
