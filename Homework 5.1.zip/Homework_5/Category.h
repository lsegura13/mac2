//
//  Category.h
//  Homework_5
//
//  Created by user122705 on 12/8/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Realm/Realm.h>
#import "Dogs.h"

@interface Category : RLMObject
@property RLMArray<Dogs *><Dogs> *dogs;
@property NSString *name;
@property NSString *imageName;
@property NSString *color;
@end
RLM_ARRAY_TYPE(Category)
