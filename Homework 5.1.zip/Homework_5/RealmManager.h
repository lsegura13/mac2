//
//  RealmManager.h
//  Homework_5
//
//  Created by user122705 on 12/8/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Realm/Realm.h>

@interface RealmManager : NSObject
+(RLMResults*)getAllCategories;
+(RLMArray*)getDogsWithCategoryName:(NSString*)categoryName;
+(void)createDogsWithCategoryName:(NSString*)categoryName dogsTitle:(NSString*)dogsTitle dogsName:(NSString*)dogsName dogsColor:(NSString*)dogsColor;
@end
