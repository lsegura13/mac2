//
//  DogsTableViewCell.m
//  Homework_5
//
//  Created by user122705 on 12/8/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "DogsTableViewCell.h"
#import "Category.h"

@interface DogsTableViewCell()
@property (weak, nonatomic) IBOutlet UIImageView *dogsImage;
@property (weak, nonatomic) IBOutlet UILabel *dogsLabelnombre;
@property (weak, nonatomic) IBOutlet UILabel *dogsLabelcolor;

@end


@implementation DogsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setupCellWithCategoryObject:(Category*)category{
    self.dogsLabelnombre.text = category.name;
    self.dogsLabelcolor.text = category.color;
    self.dogsImage.image = [UIImage imageNamed:category.imageName];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
