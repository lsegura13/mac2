//
//  AddRoutineTableViewController.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/1/16.
//  Copyright © 2016 user122705. All rights reserved.
//
@class MKMapView;

#import "AddRoutineTableViewController.h"
#import "Routine.h"
#import "RealmManager.h"
#import <MapKit/MapKit.h>
#import "MapViewController.h"


@interface AddRoutineTableViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField1;
@property (weak, nonatomic) IBOutlet UITextView *textField2;
@property (weak, nonatomic) IBOutlet UILabel *timerLabel;
@property (weak, nonatomic) NSTimer *timer2;
@property int timercount2;
@end

@implementation AddRoutineTableViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    //self.timer2;
    [self addSaveUIBarButtonItem];
    _timercount2 = 0;


}

-(void)addSaveUIBarButtonItem{
    UIBarButtonItem *saveBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(saveRoutine)];
    self.navigationItem.rightBarButtonItem = saveBarButtonItem;
}

-(void)saveRoutine{
    [RealmManager createRoutinesWithCategoryName:self.categoryName routineTitle:self.textField1.text routineDescription:self.timerLabel.text];
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self.view endEditing:YES];
}


-(void)count{
    int luis;
    luis = 0;
    _timercount2++;
    int seconds = _timercount2 % 60;
    int minutes = (_timercount2 / 60) % 60;
    int hours = _timercount2 / 3600;
    

    _timerLabel.text = [NSString stringWithFormat:@"%dh:%dm:%ds", hours, minutes,seconds];
    
}
-(IBAction)start:(id)sender{
    
    self.timer2 = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(count) userInfo:nil repeats:true];
}
-(IBAction)stop:(id)sender{
     [self.timer2 invalidate];
}
-(IBAction)restart:(id)sender{
    _timercount2 = 0;
    _timerLabel.text = [NSString stringWithFormat:@"%i", 0];
    [self.timer2 invalidate];
}

-(IBAction)map:(id)sender{
    NSLog(@"MOSTRAR MAPA");
    MapViewController *mapViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"MapViewController"];
    
    [self.navigationController pushViewController:mapViewController
                                         animated:YES];
}

#pragma mark - Table view data source

@end



