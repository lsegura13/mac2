//
//  SportsViewController.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/22/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "SportsViewController.h"
#import "Category.h"
#import "SportsCustomTableViewCell.h"
#import "RoutineViewController.h"
#import "RealmManager.h"

#define CUSTOM_CELL_ID @"SportsCustomTableViewCell"

@interface SportsViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property RLMResults *categoryArray;
@end

@implementation SportsViewController

- (void)viewDidLoad {
   /* RLMRealm *realm = [RLMRealm defaultRealm];
    [realm beginWriteTransaction];
    [realm deleteAllObjects];
    [realm commitWriteTransaction];*/
    
    [super viewDidLoad];
    self.title = @"Deportes";
    [self registerCell];
    [self initializeCategoryArray];
    

    
    // Do any additional setup after loading the view.
}

-(void)registerCell{
    UINib *nib = [UINib nibWithNibName:CUSTOM_CELL_ID bundle:nil];
    [self.tableview registerNib:nib forCellReuseIdentifier:CUSTOM_CELL_ID];
}

-(void)initializeCategoryArray{
    self.categoryArray = [RealmManager getAllCategories];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.categoryArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    SportsCustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_ID];
    Category *categoryToShow = self.categoryArray[indexPath.row];
    [cell setupCellWithCategoryObject:categoryToShow];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   RoutineViewController * routineViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"RoutineViewController"];
    Category *categorySelected = self.categoryArray[indexPath.row];
    routineViewController.categoryName = categorySelected.categoryTitle;
    [self.navigationController pushViewController:routineViewController animated:YES];
}




@end
