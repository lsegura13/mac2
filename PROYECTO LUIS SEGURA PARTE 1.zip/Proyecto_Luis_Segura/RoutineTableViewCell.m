//
//  RoutineTableViewCell.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/28/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "RoutineTableViewCell.h"
#import "Routine.h"

@interface RoutineTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *descriptionl;

@property (weak, nonatomic) IBOutlet UILabel *datelabel;
@property (weak, nonatomic) IBOutlet UILabel *descriptionl2;


@end

@implementation RoutineTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)configureCellWithRoutines:(Routine *)routineObject{
    self.descriptionl.text = routineObject.routineDescription;
    self.datelabel.text = [self getDateInStringFormatWithDate:routineObject.routineDate];
    self.descriptionl2.text = routineObject.routineTitle;
}


-(NSString*)getDateInStringFormatWithDate:(NSDate*)date{
    NSString *localizedDateTime = [NSDateFormatter localizedStringFromDate:date dateStyle:NSDateFormatterMediumStyle timeStyle:NSDateFormatterMediumStyle];
    return localizedDateTime;
}
@end
