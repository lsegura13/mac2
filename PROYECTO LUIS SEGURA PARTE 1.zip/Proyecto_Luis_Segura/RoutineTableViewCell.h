//
//  RoutineTableViewCell.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/28/16.
//  Copyright © 2016 user122705. All rights reserved.
//
@class Routine;
#import <UIKit/UIKit.h>

@interface RoutineTableViewCell : UITableViewCell
-(void)configureCellWithRoutines:(Routine*)routineObject;
@end
