//
//  MapViewController.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/20/16.
//  Copyright © 2016 user122705. All rights reserved.
//
#import "RealmManager.h"
#import <MapKit/MapKit.h>
#import "MapViewController.h"

@interface MapViewController ()<MKMapViewDelegate>
@property (strong, nonatomic) IBOutlet MKMapView *mapview;

@end

@implementation MapViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
    _mapview = [[MKMapView alloc]initWithFrame:CGRectMake(0,0,self.view.bounds.size.width,self.view.bounds.size.height)];
    _mapview.showsUserLocation = YES;
    _mapview.mapType = MKMapTypeHybrid;
    _mapview.delegate = self;
    [self.view addSubview:_mapview];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)mapView:(MKMapView *)aMapView didUpdateUserLocation:(MKUserLocation *)aUserLocation {
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    span.latitudeDelta = 0.005;
    span.longitudeDelta = 0.005;
    CLLocationCoordinate2D location;
    location.latitude = aUserLocation.coordinate.latitude;
    location.longitude = aUserLocation.coordinate.longitude;
    region.span = span;
    region.center = location;
    [aMapView setRegion:region animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
