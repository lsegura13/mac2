//
//  UITableView+Routine.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/1/16.
//  Copyright © 2016 user122705. All rights reserved.
//


#import "UITableView+Routine.h"

@implementation UITableView (RegisterCustomCell)


-(void)registerCellWithIdentifier:(NSString*)identifier{
    UINib *nib = [UINib nibWithNibName:identifier bundle:nil];
    [self registerNib:nib forCellReuseIdentifier:identifier];
}

@end
