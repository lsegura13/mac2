//
//  RoutineViewController.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/28/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "RoutineViewController.h"
#import "AddRoutineTableViewController.h"
#import "SportsViewController.h"
#import "RoutineTableViewCell.h"
#import "UITableView+Routine.h"
#import <Realm/Realm.h>
#import "RealmManager.h"

#define CUSTOM_CELL_ID @"RoutineTableViewCell"

@interface RoutineViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property RLMArray *routineArray;
@end

@implementation RoutineViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self registerCell];
    [self createAddNewsUIBarButtonItem];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear: animated];
    [self loadRoutine];
}

-(void)loadRoutine{
    self.routineArray = [RealmManager getRoutinesWithCategoryName:self.categoryName];
    [self.tableView reloadData];
}

-(void)createAddNewsUIBarButtonItem{
    UIBarButtonItem *addItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addItem)];
    self.navigationItem.rightBarButtonItem = addItem;
}

-(void)addItem{
    AddRoutineTableViewController *addRoutineTableViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AddRoutineTableViewController"];
    addRoutineTableViewController.categoryName = self.categoryName;
    [self.navigationController pushViewController:addRoutineTableViewController
                                         animated:YES];
}

-(void)registerCell{
    [self.tableView registerCellWithIdentifier:CUSTOM_CELL_ID];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.routineArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RoutineTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_ID];
    [cell configureCellWithRoutines:(Routine*)self.routineArray[indexPath.row]];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;
}

// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.routineArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}

@end
