//
//  SportsCustomTableViewCell.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/22/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "SportsCustomTableViewCell.h"
#import "Category.h"

@interface SportsCustomTableViewCell()
@property (weak, nonatomic) IBOutlet UIImageView *image;
@property (weak, nonatomic) IBOutlet UILabel *label;
@end

@implementation SportsCustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setupCellWithCategoryObject:(Category*)category{
    self.label.text = category.categoryTitle;
    self.image.image = [UIImage imageNamed:category.imageName];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
