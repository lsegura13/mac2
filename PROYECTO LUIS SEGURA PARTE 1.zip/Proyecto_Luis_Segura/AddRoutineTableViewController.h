//
//  AddRoutineTableViewController.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/1/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <UIKit/UIKit.h>
//int timercount2;
@interface AddRoutineTableViewController : UITableViewController
@property(nonatomic,strong) NSString *categoryName;

@property (strong, nonatomic) IBOutlet UILabel *timerlabel;

-(void)count;
-(IBAction)start:(id)sender;
-(IBAction)stop:(id)sender;
-(IBAction)restart:(id)sender;
-(IBAction)map:(id)sender;


@end
