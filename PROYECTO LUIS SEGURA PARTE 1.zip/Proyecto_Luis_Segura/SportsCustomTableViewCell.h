//
//  SportsCustomTableViewCell.h
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 11/22/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import <UIKit/UIKit.h>


@class Category;
@interface SportsCustomTableViewCell : UITableViewCell
-(void)setupCellWithCategoryObject:(Category*)category;
@end

