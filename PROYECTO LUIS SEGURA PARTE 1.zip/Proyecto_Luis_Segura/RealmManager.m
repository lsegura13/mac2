//
//  RealmManager.m
//  Proyecto_Luis_Segura
//
//  Created by user122705 on 12/9/16.
//  Copyright © 2016 user122705. All rights reserved.
//

#import "RealmManager.h"
#import "Category.h"
#import "Routine.h"

#define CATEGORY_NAME_KEY @"CATEGORY_NAME_KEY"
#define CATEGORY_IMAGE_NAME_KEY @"CATEGORY_IMAGE_NAME_KEY"

@implementation RealmManager


+(RLMResults*)getAllCategories{
    if ([self needsToInsertCategories]) {
        [self createDefaultCategories];
    }
    return [Category allObjects];
}

+(BOOL)needsToInsertCategories{
    RLMResults<Category *> *categories = [Category allObjects]; // retrieves all Categories from the default Realm
    if (categories.count==0) {
        return true;
    }
    return false;
}


+(NSArray*)createCategoriesDictionary{
    return [[NSArray alloc] initWithObjects:
            @{CATEGORY_NAME_KEY:@"Ciclismo", CATEGORY_IMAGE_NAME_KEY:@"ciclismo"},
            @{CATEGORY_NAME_KEY:@"Natacion", CATEGORY_IMAGE_NAME_KEY:@"natacion"},
            @{CATEGORY_NAME_KEY:@"Atletismo", CATEGORY_IMAGE_NAME_KEY:@"running"},
            @{CATEGORY_NAME_KEY:@"Otros", CATEGORY_IMAGE_NAME_KEY:@"otros"},
            nil];
}

+(void)createDefaultCategories{
    NSArray *categoryArray = [self createCategoriesDictionary];
    for (NSDictionary *categoryDictionary in categoryArray) {
        Category *category = [Category new];
        category.imageName = [categoryDictionary valueForKey:CATEGORY_IMAGE_NAME_KEY];
        category.categoryTitle = [categoryDictionary valueForKey:CATEGORY_NAME_KEY];
        [self insertObjectInDB:category];
    }
}



+(void)insertObjectInDB:(RLMObject*)realmObject{
    RLMRealm *realm = [RLMRealm defaultRealm];
    // Add to Realm with transaction
    [realm beginWriteTransaction];
    [realm addObject:realmObject];
    [realm commitWriteTransaction];
}

+(Category*)getCategoryWithName:(NSString*)categoryName{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.categoryTitle = %@",categoryName];
    RLMResults<Category *> *categories = [Category objectsWithPredicate:predicate];
    if (categories.count>0) {
        return categories.firstObject;
    }
    return nil;
}

+(RLMArray*)getRoutinesWithCategoryName:(NSString*)categoryName{
    Category *category = [self getCategoryWithName:categoryName];
    return category.routine;
}

+(void)createRoutinesWithCategoryName:(NSString*)categoryName routineTitle:(NSString*)routineTitle routineDescription:(NSString*)routineDescription{
    Category *categorySelected = [self getCategoryWithName:categoryName];
    Routine *routine = [Routine new];
    routine.routineDate= [NSDate date];
    routine.routineTitle = routineTitle;
    routine.routineDescription = routineDescription;
    //routine.routineTime = routineTime;
    
    RLMRealm *realm = [RLMRealm defaultRealm];
    [realm beginWriteTransaction];
    [realm addObject:routine];
    [categorySelected.routine addObject:routine];
    [realm commitWriteTransaction];
}

+(void)delete{
     RLMRealm *realm = [RLMRealm defaultRealm];
     [realm beginWriteTransaction];
    [realm deleteAllObjects];
    [realm commitWriteTransaction];    
    }

+(void)addobject{
    RLMRealm *realm = [RLMRealm defaultRealm];
    [realm beginWriteTransaction];
    [realm deleteAllObjects];
    [realm commitWriteTransaction];
}
@end
