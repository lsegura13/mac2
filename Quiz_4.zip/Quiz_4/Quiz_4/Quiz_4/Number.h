//
//  Number.h
//  Quiz_4
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Number : NSObject
@property(readonly) NSString *numero;
-(id)initWithNumero:(NSString*)numero;
@end
