//
//  Number.m
//  Quiz_4
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "Number.h"
@interface Number()
@property(nonatomic,strong) NSString *numero;
@end

@implementation Number
-(id)initWithNumero:(NSString*)numero{
    if (self = [super init]) {
        _numero = numero;
    }
    return self;
}@end
