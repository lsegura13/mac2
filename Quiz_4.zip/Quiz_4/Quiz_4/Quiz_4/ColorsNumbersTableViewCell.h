//
//  ColorsNumbersTableViewCell.h
//  Quiz_4
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Numero;

@interface ColorsNumbersTableViewCell : UITableViewCell

-(void)setupCellWithNumero:(Numero*)num;

@end
