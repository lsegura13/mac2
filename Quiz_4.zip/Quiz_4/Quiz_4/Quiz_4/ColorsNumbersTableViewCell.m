//
//  ColorsNumbersTableViewCell.m
//  Quiz_4
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "ColorsNumbersTableViewCell.h"
#import "Number.h"

@interface ColorsNumbersTableViewCell()
@property (strong, nonatomic) IBOutlet UILabel *label;



@end



@implementation ColorsNumbersTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setupCellWithNumero:(Number*)numero{
    self.label.text = numero.numero;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
