//
//  ColorNumbersViewController.m
//  Quiz_4
//
//  Created by Estudiantes on 19/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "ColorNumbersViewController.h"
#import "ColorsNumbersTableViewCell.h"
#import "Number.h"
#define CUSTOM_CELL_IDENTIFIER @"ColorsNumbersTableViewCell"


@interface ColorNumbersViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *TableView;
@property (nonatomic, strong) NSArray *numerosArray;

@end

@implementation ColorNumbersViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self registerCustomCell];
    [self initializeNumerosArray];
    
    
    NSLog(@"SERIE");
    

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)registerCustomCell{
    UINib *nib = [UINib nibWithNibName:CUSTOM_CELL_IDENTIFIER bundle:nil];
    [self.TableView registerNib:nib forCellReuseIdentifier:CUSTOM_CELL_IDENTIFIER];
}

-(void)initializeNumerosArray{
    NSMutableArray *numArray = [NSMutableArray new];
    ColorsNumbersTableViewCell *myview = [[ColorsNumbersTableViewCell alloc] init];
    for(int index=0; index <5001; index++){
        if(index/2 == 0)
        {
            Number *newNumber =[[Number alloc] initWithNumero:[NSString stringWithFormat:@"%d",index]];
            [numArray addObject:newNumber];
            myview.backgroundColor = [UIColor blueColor];
            
        }
        else
        {
            Number *newNumber =[[Number alloc] initWithNumero:[NSString stringWithFormat:@"%d",index]];            [numArray addObject:newNumber];
            myview.backgroundColor = [UIColor redColor];
            
        }
        
    }
    self.numerosArray = [[NSArray alloc] initWithArray:numArray];
}

#pragma -mark TABLE VIEW METHODS

-(NSInteger)tableView:(UITableView *)TableView numberOfRowsInSection:(NSInteger)section{
    return  self.numerosArray.count;
}

-(CGFloat)tableView:(UITableView *)TableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 160;
    
}

-(UITableViewCell *)tableView:(UITableView *)TableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ColorsNumbersTableViewCell *cell = [TableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_IDENTIFIER];
    Numero *numeroToShow = self.numerosArray[indexPath.row];
    [cell setupCellWithNumero :numeroToShow];
    return cell;
}



@end
