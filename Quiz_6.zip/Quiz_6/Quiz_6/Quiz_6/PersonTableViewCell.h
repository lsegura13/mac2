//
//  PersonTableViewCell.h
//  Quiz_6
//
//  Created by Estudiantes on 3/12/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Person;
@interface PersonTableViewCell : UITableViewCell
-(void)setupCellWithPerson:(Person*)person;

@end
