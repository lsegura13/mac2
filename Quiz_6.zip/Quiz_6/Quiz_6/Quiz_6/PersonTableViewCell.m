//
//  PersonTableViewCell.m
//  Quiz_6
//
//  Created by Estudiantes on 3/12/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "PersonTableViewCell.h"
#import "Person.h"
@interface PersonTableViewCell()
@property (strong, nonatomic) IBOutlet UILabel *labelorder;
@property (strong, nonatomic) IBOutlet UILabel *labelname;

@end
@implementation PersonTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setupCellWithPerson:(Person*)person{
    self.labelorder.text = person.order;
    self.labelname.text = person.name;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
