//
//  Person.h
//  Quiz_6
//
//  Created by Estudiantes on 3/12/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
@property(readonly) NSString *order;
@property(readonly) NSString *name;
-(id)initWithName:(NSString*)order name:(NSString*)name;
@end
