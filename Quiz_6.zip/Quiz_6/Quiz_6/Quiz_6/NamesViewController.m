//
//  NamesViewController.m
//  Quiz_6
//
//  Created by Estudiantes on 3/12/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "NamesViewController.h"
#import "Person.h"
#import "PersonTableViewCell.h"


#define ORDER @"order"
#define NAME @"name"
#define CUSTOM_CELL_IDENTIFIER @"PersonTableViewCell"

@interface NamesViewController ()<UITableViewDelegate, UITableViewDataSource>
@property(nonatomic,strong) NSArray *personArray;
@property (strong, nonatomic) IBOutlet UITableView *tableView;



@end

@implementation NamesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)registerCustomCell{
    UINib *nib = [UINib nibWithNibName:CUSTOM_CELL_IDENTIFIER bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:CUSTOM_CELL_IDENTIFIER];
}


-(void)createDictionary{
    
    NSDictionary *firstDictionary = @{ORDER:@"4",NAME:@"Enrique"};
    NSDictionary *secondDictionary = @{ORDER:@"5",NAME:@"Cristian"};
    NSDictionary *thirdDictionary = @{ORDER:@"1",NAME:@"Javier"};
    NSDictionary *fourthDictionary = @{ORDER:@"2",NAME:@"Carlos"};
    NSDictionary *fifthDictionary = @{ORDER:@"10",NAME:@"Alejandro"};
    NSDictionary *sixthDictionary = @{ORDER:@"9",NAME:@"Abismei"};
    NSDictionary *seventhDictionary = @{ORDER:@"8",NAME:@"Ignacio"};
    NSDictionary *eigthDictionary = @{ORDER:@"7",NAME:@"Luis"};
    NSDictionary *ninethDictionary = @{ORDER:@"6",NAME:@"Alonso"};
    NSDictionary *tenthDictionary = @{ORDER:@"3",NAME:@"Sergio"};

    self.personArray = [[NSArray alloc] initWithObjects:firstDictionary,secondDictionary,thirdDictionary,fourthDictionary,fifthDictionary,sixthDictionary,seventhDictionary,eigthDictionary,ninethDictionary,tenthDictionary, nil];
}

-(NSInteger)tableView:(UITableView *)TableView numberOfRowsInSection:(NSInteger)section{
    return  self.personArray.count;
}

-(CGFloat)tableView:(UITableView *)TableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 160;
    
}

-(UITableViewCell *)tableView:(UITableView *)TableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    PersonTableViewCell *cell = [TableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_IDENTIFIER];
    Person *personToShow = self.personArray[indexPath.row];
    [cell setupCellWithPerson:personToShow];
    return cell;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
