//
//  NamesViewController.h
//  Quiz_6
//
//  Created by Estudiantes on 3/12/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NamesViewController : UIViewController

@end
