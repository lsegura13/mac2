//
//  Person.m
//  Quiz_6
//
//  Created by Estudiantes on 3/12/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "Person.h"

@interface Person()
@property(nonatomic,strong) NSString *name;
@property(nonatomic,strong) NSString *order;
@end

@implementation Person
-(id)initWithName:(NSString*)order name:(NSString*)name{
    if (self = [super init]) {
        _name = name;
        _order = order;
    }
    return self;
}@end
