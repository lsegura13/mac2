//
//  AppDelegate.h
//  CustomTableViewExample
//
//  Created by Cesar Brenes on 11/5/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

