//
//  CustomTableViewCell.h
//  CustomTableViewExample
//
//  Created by Cesar Brenes on 11/5/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Dog;
@interface CustomTableViewCell : UITableViewCell
-(void)setupCellWithDog:(Dog*)dog;
    @end
