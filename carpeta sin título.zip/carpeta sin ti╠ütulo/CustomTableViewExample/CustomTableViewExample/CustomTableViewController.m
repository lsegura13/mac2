//
//  CustomTableViewController.m
//  CustomTableViewExample
//
//  Created by Cesar Brenes on 11/5/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import "CustomTableViewController.h"
#import "Dog.h"
#import "CustomTableViewCell.h"

#define CUSTOM_CELL_IDENTIFIER @"CustomTableViewCell"

@interface CustomTableViewController () <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSArray *dogsArray;
@end

@implementation CustomTableViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [self registerCustomCell];
    [self initializeDogsArray];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)registerCustomCell{
    UINib *nib = [UINib nibWithNibName:CUSTOM_CELL_IDENTIFIER bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:CUSTOM_CELL_IDENTIFIER];
}

-(void)initializeDogsArray{
    NSMutableArray *dogsArray = [NSMutableArray new];
    for(int index=0; index <=1000; index++){
        Dog *newDog =[[Dog alloc] initWithName:[NSString stringWithFormat:@"Dog%d",index] color:[NSString stringWithFormat:@"Color%d", index]];
        [dogsArray addObject:newDog];
    }
    self.dogsArray = [[NSArray alloc] initWithArray:dogsArray];
    
}



#pragma -mark TABLE VIEW METHODS

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  self.dogsArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 160;

}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CUSTOM_CELL_IDENTIFIER];
    Dog *dogToShow = self.dogsArray[indexPath.row];
    [cell setupCellWithDog:dogToShow];
    return cell;
}



@end
