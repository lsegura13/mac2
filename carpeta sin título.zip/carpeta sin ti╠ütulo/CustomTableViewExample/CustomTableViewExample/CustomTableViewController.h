//
//  CustomTableViewController.h
//  CustomTableViewExample
//
//  Created by Cesar Brenes on 11/5/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomTableViewController : UIViewController

@end
