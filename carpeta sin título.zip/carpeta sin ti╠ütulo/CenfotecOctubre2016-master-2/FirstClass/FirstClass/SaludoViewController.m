//
//  SaludoViewController.m
//  FirstClass
//
//  Created by Estudiantes on 29/10/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import "SaludoViewController.h"

@interface SaludoViewController ()
@property (strong, nonatomic) IBOutlet UILabel *NameLabel;

@end

@implementation SaludoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.NameLabel.text = [NSString stringWithFormat:@"hola %@", [self.personName uppercaseString]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
