//
//  SaludoViewController.h
//  FirstClass
//
//  Created by Estudiantes on 29/10/16.
//  Copyright © 2016 Cesar Brenes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SaludoViewController : UIViewController
@property(nonatomic,strong) NSString *personName;
@end
