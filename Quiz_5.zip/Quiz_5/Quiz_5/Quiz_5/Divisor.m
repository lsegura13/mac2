//
//  Divisor.m
//  Quiz_5
//
//  Created by Estudiantes on 26/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "Divisor.h"
@interface Divisor()
@property(nonatomic,strong) NSString *numero;
@end

@implementation Divisor
-(id)initWithNumero:(NSString*)numero{
    if (self = [super init]) {
        _numero = numero;
    }
    return self;
}@end
