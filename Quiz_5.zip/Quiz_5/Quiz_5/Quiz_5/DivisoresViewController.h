//
//  DivisoresViewController.h
//  Quiz_5
//
//  Created by Estudiantes on 26/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DivisoresViewController : UIViewController

@end
