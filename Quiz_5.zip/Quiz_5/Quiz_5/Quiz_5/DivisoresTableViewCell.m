//
//  DivisoresTableViewCell.m
//  Quiz_5
//
//  Created by Estudiantes on 26/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import "DivisoresTableViewCell.h"
#import "Divisor.h"

@interface DivisoresTableViewCell()
@property (strong, nonatomic) IBOutlet UILabel *label;


@end

@implementation DivisoresTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

-(void)setupCellWithNumero:(Divisor*)numero{
    self.label.text = numero.numero;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
