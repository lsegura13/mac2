//
//  DivisoresTableViewCell.h
//  Quiz_5
//
//  Created by Estudiantes on 26/11/16.
//  Copyright © 2016 Estudiantes. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Divisor;

@interface DivisoresTableViewCell : UITableViewCell
-(void)setupCellWithNumero:(Divisor*)num;

@end
